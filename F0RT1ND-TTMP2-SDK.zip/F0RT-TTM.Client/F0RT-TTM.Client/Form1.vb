﻿Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Public Class Form1
    Dim client As TcpClient
    Dim stream As NetworkStream
    Dim listenerThread As Thread
    Dim username As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Populate emojis dropdown
        cmbEmojis.Items.AddRange(New String() {"😀", "😂", "😍", "😎", "😭", "👍", "❤️"})
        cmbEmojis.SelectedIndex = 0
    End Sub
    Private Sub ReceiveMessages()
        Dim buffer(1024) As Byte

        Try
            While True
                Dim bytesRead As Integer = stream.Read(buffer, 0, buffer.Length)
                If bytesRead = 0 Then Exit While

                Dim message As String = Encoding.UTF8.GetString(buffer, 0, bytesRead)
                Invoke(Sub() ListBox1.Items.Add(message))
            End While
        Catch ex As Exception
            MessageBox.Show("Disconnected from server.")
        Finally
            Client.Close()
        End Try
    End Sub

    Private Sub btnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        If txtUsername.Text.Trim() = "" Then
            MessageBox.Show("Please enter a username.")
            Return
        End If

        username = txtUsername.Text.Trim()
        Try
            Client = New TcpClient("127.0.0.1", 8888)
            stream = Client.GetStream()

            ' Send username to the server
            Dim buffer As Byte() = Encoding.UTF8.GetBytes(username)
            stream.Write(buffer, 0, buffer.Length)

            ' Start listening for messages
            listenerThread = New Thread(AddressOf ReceiveMessages)
            listenerThread.Start()

            ' Disable username input after connecting
            txtUsername.ReadOnly = True
            btnConnect.Enabled = False
        Catch ex As Exception
            MessageBox.Show("Could not connect to server.")
        End Try
    End Sub

    Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        If client IsNot Nothing AndAlso client.Connected Then
            Dim message As String = txtMessage.Text & " " & cmbEmojis.SelectedItem.ToString()
            Dim buffer As Byte() = Encoding.UTF8.GetBytes(message)
            stream.Write(buffer, 0, buffer.Length) ' Send message to server
            stream.Flush() ' Ensure the message is sent immediately

            ListBox1.Items.Add("Me: " & message) ' Show message in chatbox
            txtMessage.Clear() ' Clear message input
        Else
            MessageBox.Show("Not connected to the server.")
        End If
    End Sub
End Class
