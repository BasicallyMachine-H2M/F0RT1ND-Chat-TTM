﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Module Module1
    Dim clients As New Dictionary(Of TcpClient, String)()

    Sub HandleClient(client As TcpClient)
        Dim stream As NetworkStream = client.GetStream()
        Dim buffer(1024) As Byte

        Try
            ' Read username first
            Dim bytesRead As Integer = stream.Read(buffer, 0, buffer.Length)
            Dim username As String = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim()
            clients(client) = username
            Console.WriteLine(username & " has joined the chat.")

            ' Broadcast join message
            BroadcastMessage("🟢 " & username & " has joined the chat!", client)

            While True
                bytesRead = stream.Read(buffer, 0, buffer.Length)
                If bytesRead = 0 Then Exit While

                Dim message As String = Encoding.UTF8.GetString(buffer, 0, bytesRead)
                Console.WriteLine(username & ": " & message)
                BroadcastMessage(username & ": " & message, client)
            End While
        Catch ex As Exception
            Console.WriteLine("Client disconnected.")
        Finally
            If clients.ContainsKey(client) Then
                Dim username As String = clients(client)
                clients.Remove(client)
                BroadcastMessage("🔴 " & username & " has left the chat.", client)
            End If
            client.Close()
        End Try
    End Sub
    Sub BroadcastMessage(message As String, sender As TcpClient)
        Dim buffer As Byte() = Encoding.UTF8.GetBytes(message)
        For Each client In clients.Keys
            If client IsNot sender Then
                client.GetStream().Write(buffer, 0, buffer.Length)
            End If
        Next
    End Sub
    Sub Main()
        Dim listener As New TcpListener(IPAddress.Any, 8888)
        listener.Start()
        Console.WriteLine("Server started on port 8888...")

        While True
            Dim client As TcpClient = listener.AcceptTcpClient()
            Dim clientThread As New Thread(AddressOf HandleClient)
            clientThread.Start(client)
        End While
    End Sub

End Module
